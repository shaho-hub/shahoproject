from flask import Flask, request, jsonify
import telebot

app = Flask(name)

# توكن البوت
TOKEN = "8249297425:AAHpiFQyZjOFmaHIk8vJoApseCcXqKBPdXY"
bot = telebot.TeleBot(TOKEN)

# chat_id مالك
CHAT_ID = 5314063478

# تخزين البيانات مؤقت (يمكن لاحقاً تخزينها بملف أو DB)
data_storage = {}

@app.route('/submit_data', methods=['POST'])
def submit_data():
    data = request.json

    if not data:
        return jsonify({"status": "error", "message": "No JSON received"})

    collected_data = data.get('data')

    if collected_data:
        # حفظ البيانات
        data_storage[CHAT_ID] = collected_data

        try:
            # إرسال للبوت
            bot.send_message(CHAT_ID, f"✅ تم استلام البيانات:\n{collected_data}")
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)})

        return jsonify({"status": "success"})

    return jsonify({"status": "error", "message": "Missing data"})


if name == 'main':
    app.run(host="0.0.0.0", port=5000, debug=True)